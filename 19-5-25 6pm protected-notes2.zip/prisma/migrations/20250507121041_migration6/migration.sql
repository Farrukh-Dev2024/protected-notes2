-- AlterTable
ALTER TABLE "List" ADD COLUMN     "title" TEXT DEFAULT '';
